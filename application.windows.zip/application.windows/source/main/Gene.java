package main;

import java.util.ArrayList;
import java.util.Hashtable;

import edu.uic.ncdm.venn.Venn_Overview;

import static main.MainViewer.pairs;
import static main.MainViewer.ggg;
import static main.MainViewer.geneRelationList;
import static edu.uic.ncdm.venn.Venn_Overview.numMinerContainData;
import static edu.uic.ncdm.venn.Venn_Overview.minerGlobalIDof;;


public class Gene {
	// For a gene, we have the count number of each type of relations
	public static Hashtable<String, int[]> hGenes = new Hashtable<String,int[]>();
	public static int maxRelationOfGenes = -1;
	public String name = "????";
	public Integrator iX, iY, iH,iW;
	public int order;
	public int orderReading;
//	public int orderParent;
	
	public Gene(String name_, int order_){
		name = name_;
		iX = new Integrator(main.MainViewer.marginX,.5f,.1f);
		iY = new Integrator(main.MainViewer.marginY,.5f,.1f);
		iW = new Integrator(0,.5f,.1f);
		iH = new Integrator(0,.5f,.1f);
		order = order_;
		orderReading = order;
	//	orderParent = order;
	}
	
	public static void compute(){
		 hGenes = new Hashtable<String,int[]>();
		 for (int i=0; i<main.MainViewer.allGenes.size();i++){
			 hGenes.put(main.MainViewer.allGenes.get(i), new int[numMinerContainData]);
		 }
		 maxRelationOfGenes = -1;
		 for (int j=0; j<numMinerContainData;j++){
			 int m =  minerGlobalIDof[j];
			 for (int p=0; p<pairs[m].size();p++){
				 String g = pairs[m].get(p).split("\t")[0];
				 int[] list =  hGenes.get(g);
				 list[j]++;
				 // compute max number of relationships
				 if (list[j]>maxRelationOfGenes)
					 maxRelationOfGenes = list[j];
				 hGenes.put(g, list);
			 }
		}
	}
	
	@SuppressWarnings("unchecked")
	public static void computeGeneRalationList(){
		geneRelationList = new ArrayList[ggg.size()][ggg.size()];
		for (int localMinerID=0;localMinerID<Venn_Overview.minerGlobalIDof.length;localMinerID++){
			int globalMinerId = Venn_Overview.minerGlobalIDof[localMinerID];
		    for (int i=0;i<ggg.size();i++){
				for (int j=0;j<ggg.size();j++){
					if (pairs[globalMinerId].contains(ggg.get(i).name+"\t"+ggg.get(j).name)){
						if (geneRelationList[i][j]==null)
							geneRelationList[i][j] = new ArrayList<Integer>();
						geneRelationList[i][j].add(localMinerID);
					}
				}
			}
		 }	
	 }	 
}
