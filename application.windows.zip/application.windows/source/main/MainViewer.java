package main;
/*
 * DARPA project
 *
 * Copyright 2014 by Tuan Dang.
 *
 * The contents of this file are subject to the Mozilla Public License Version 2.0 (the "License")
 * You may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the License.
 */

import static javax.swing.JOptionPane.showMessageDialog;
import static main.MainViewer.geneRelationList;
import static main.MainViewer.ggg;
import static main.MainViewer.minerList;
import static main.MainViewer.pairs;

import java.awt.Color;
import java.awt.FileDialog;
import java.awt.Frame;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.biopax.paxtools.io.SimpleIOHandler;
import org.biopax.paxtools.model.BioPAXElement;
import org.biopax.paxtools.model.Model;
import org.biopax.paxtools.pattern.Match;
import org.biopax.paxtools.pattern.Pattern;
import org.biopax.paxtools.pattern.Searcher;
import org.biopax.paxtools.pattern.miner.CSCOBothControllerAndParticipantMiner;
import org.biopax.paxtools.pattern.miner.CSCOButIsParticipantMiner;
import org.biopax.paxtools.pattern.miner.CSCOThroughBindingSmallMoleculeMiner;
import org.biopax.paxtools.pattern.miner.CSCOThroughControllingSmallMoleculeMiner;
import org.biopax.paxtools.pattern.miner.CSCOThroughDegradationMiner;
import org.biopax.paxtools.pattern.miner.CatalysisPrecedesMiner;
import org.biopax.paxtools.pattern.miner.ChemicalAffectsThroughBindingMiner;
import org.biopax.paxtools.pattern.miner.ChemicalAffectsThroughControlMiner;
import org.biopax.paxtools.pattern.miner.ConsumptionControlledByMiner;
import org.biopax.paxtools.pattern.miner.ControlsDegradationIndirectMiner;
import org.biopax.paxtools.pattern.miner.ControlsExpressionMiner;
import org.biopax.paxtools.pattern.miner.ControlsExpressionWithConvMiner;
import org.biopax.paxtools.pattern.miner.ControlsPhosphorylationMiner;
import org.biopax.paxtools.pattern.miner.ControlsProductionOfMiner;
import org.biopax.paxtools.pattern.miner.ControlsStateChangeDetailedMiner;
import org.biopax.paxtools.pattern.miner.ControlsStateChangeOfMiner;
import org.biopax.paxtools.pattern.miner.ControlsTransportMiner;
import org.biopax.paxtools.pattern.miner.ControlsTransportOfChemicalMiner;
import org.biopax.paxtools.pattern.miner.DirectedRelationMiner;
import org.biopax.paxtools.pattern.miner.InComplexWithMiner;
import org.biopax.paxtools.pattern.miner.InteractsWithMiner;
import org.biopax.paxtools.pattern.miner.Miner;
import org.biopax.paxtools.pattern.miner.NeighborOfMiner;
import org.biopax.paxtools.pattern.miner.ReactsWithMiner;
import org.biopax.paxtools.pattern.miner.RelatedGenesOfInteractionsMiner;
import org.biopax.paxtools.pattern.miner.UbiquitousIDMiner;
import org.biopax.paxtools.pattern.miner.UsedToProduceMiner;
import org.biopax.paxtools.pattern.util.Blacklist;

import static edu.uic.ncdm.venn.Venn_Overview.*;
import edu.uic.ncdm.venn.Venn_Overview;
import edu.uic.ncdm.venn.Venn_Detail;

import processing.core.*;

public class MainViewer extends PApplet {
	private static final long serialVersionUID = 1L;
	public int count = 0;
	/**
	 * The name of the file for IDs of ubiquitous molecules.
	 */
	private static final String UBIQUE_FILE = "blacklist.txt";

	/**
	 * The url of the file for IDs of ubiquitous molecules.
	 */
	private static final String UBIQUE_URL = "http://www.pathwaycommons.org/pc2/downloads/blacklist.txt";


	/**
	 * Blacklist for detecting ubiquitous small molecules.
	 */
	private static Blacklist blacklist;
	public static List<Miner> minerList = new ArrayList<Miner>();
	public static int currentRelation = -1;
	public static int processingMiner = 0;
	//public String currentFile = "../level3/Regulation of DNA Replication.owl";
	public String currentFile = "../level3/ATM Mediated Phosphorylation of Repair Proteins.owl";
	
	public static Button button;
	
	// Store the genes results
	public static ArrayList<String>[] pairs;
	public static ArrayList<String>[] genes;
	public static ArrayList<Integer>[][] geneRelationList;
	
	// Global data
	public static ArrayList<String> allGenes = new ArrayList<String>();
	public static String[] minerNames;
	//public static ArrayList<String> gen = new ArrayList<String>();
	public static ArrayList<Gene> ggg = new ArrayList<Gene>();
	
	
	//public static ArrayList<Integrator> iW;
	// Contains the location and size of each gene to display
	public float size=0;
	public static float marginX = 100;
	public static float marginY = 100;
	public static String message="";
	
	public ThreadLoader1 loader1=new ThreadLoader1();
	public Thread thread1=new Thread(loader1);
	
	public ThreadLoader2 loader2=new ThreadLoader2();
	public Thread thread2=new Thread(loader2);
	
	public ThreadLoader3 loader3=new ThreadLoader3();
	public Thread thread3=new Thread(loader3);
	
	// Venn
	public Venn_Overview vennOverview; 
	public Venn_Detail vennDetail; 
	
	public boolean isLensing = true;
	public int bX,bY;
	
	// Order genes
	public static PopupRelations popupRelation;
	public static PopupOrders popupOrder;
	
	public static void main(String args[]){
	  PApplet.main(new String[] { MainViewer.class.getName() });
    }

	static{
		File f = new File(UBIQUE_FILE);

		if (!f.exists()) downloadUbiques();
		else if (f.exists()) blacklist = new Blacklist(f.getAbsolutePath());
		else System.out.println("Warning: Cannot load blacklist.");
	}
	/**
	 * Downloads the PC data.
	 * @return true if download successful
	 */
	private static boolean downloadUbiques(){
		return downloadPlain(UBIQUE_URL, UBIQUE_FILE);
	}
	private static boolean downloadPlain(String urlString, String file){
		try{
			URL url = new URL(urlString);
			URLConnection con = url.openConnection();
			InputStream in = con.getInputStream();

			// Open the output file
			OutputStream out = new FileOutputStream(file);
			// Transfer bytes from the compressed file to the output file
			byte[] buf = new byte[1024];

			int lines = 0;
			int len;
			while ((len = in.read(buf)) > 0){
				out.write(buf, 0, len);
				lines++;
			}
			// Close the file and stream
			in.close();
			out.close();

			return lines > 0;
		}
		catch (IOException e){return false;}
	}
	
	

	public void setup() {
		button = new Button(this);
		size(1440, 900);
		//size(2000, 1200);
		if (frame != null) {
		    frame.setResizable(true);
		  }
		background(0);
		frameRate(20);
		curveTightness(0.7f); 
		smooth();
		
		// Get the output file
		minerList.add(new DirectedRelationMiner());
		minerList.add(new ControlsStateChangeOfMiner());
		//minerList.add(new CSCOButIsParticipantMiner());
		//minerList.add(new CSCOBothControllerAndParticipantMiner());
		//minerList.add(new CSCOThroughControllingSmallMoleculeMiner());
		//minerList.add(new CSCOThroughBindingSmallMoleculeMiner());
		//minerList.add(new ControlsStateChangeDetailedMiner());
		//minerList.add(new ControlsPhosphorylationMiner());
		minerList.add(new ControlsTransportMiner());
		minerList.add(new ControlsExpressionMiner());
		minerList.add(new ControlsExpressionWithConvMiner());
		//minerList.add(new CSCOThroughDegradationMiner());
		minerList.add(new ControlsDegradationIndirectMiner());
		minerList.add(new ConsumptionControlledByMiner());
		minerList.add(new ControlsProductionOfMiner());
		minerList.add(new CatalysisPrecedesMiner());
		minerList.add(new ChemicalAffectsThroughBindingMiner());
		minerList.add(new ChemicalAffectsThroughControlMiner());
		minerList.add(new ControlsTransportOfChemicalMiner());
		minerList.add(new InComplexWithMiner());
		minerList.add(new InteractsWithMiner());
		minerList.add(new NeighborOfMiner());
		minerList.add(new ReactsWithMiner());
		minerList.add(new UsedToProduceMiner());
		minerList.add(new RelatedGenesOfInteractionsMiner());
		minerList.add(new UbiquitousIDMiner());
	
		button = new Button(this);
		popupRelation = new PopupRelations(this);
		popupOrder  = new PopupOrders(this);
		
		//VEN DIAGRAM
		vennOverview = new Venn_Overview(this);
		vennDetail = new Venn_Detail(this);
		thread1=new Thread(loader1);
		thread1.start();
		
		
	}	
	
	
	public void computeRelationship(String fileName, int relID) {
		File modFile = new File(fileName);
		File outFile = new File("output.txt");
		SimpleIOHandler io = new SimpleIOHandler();
		Model model;
		try{
			model = io.convertFromOWL(new FileInputStream(modFile));
		}
		catch (FileNotFoundException e){
			e.printStackTrace();
			showMessageDialog(this, "File not found: " + modFile.getPath());
			return;
		}

		// Search
		Miner min = minerList.get(relID);
		Pattern p = min.getPattern();
		Map<BioPAXElement,List<Match>> matches = Searcher.search(model, p, null);

		try{
			FileOutputStream os = new FileOutputStream(outFile);
			min.writeResult(matches, os);
			
			os.close();
		}
		catch (IOException e){
			e.printStackTrace();
			showMessageDialog(this, "Error occurred while writing the results");
			return;
		}
		//	System.out.println("Success! Outfile="+outFile);
	}
		
	
	
	public void draw() {
		background(0);
		
		// Print message
		if (processingMiner<minerList.size()){
			float val = (float) processingMiner/(minerList.size()-1);
			Color colorMiner = ColorScales.getColor(val, "rainbow", 1f);
			this.fill(colorMiner.getRGB());
			this.text(message, marginX+10,this.height-8);
		}
		
		
		if (ggg==null || ggg.size()==0)
			return;
		else{
			size = (this.height-marginY)/allGenes.size();
			size = size*0.75f;
			if (size>100)
				size=100;
		}
		
		
		// Compute lensing
		if (isLensing){
			bX =  (int) ((mouseX-marginX)/size);
			bY =  (int) ((mouseY-marginY)/size);
		}
		float lensingSize = PApplet.map(size, 0, 100, 25, 120);	
		
		int num = 4; // Number of items in one side of lensing
		for (int i=0;i<ggg.size();i++){
			int order = ggg.get(i).order;
			if (bX-num<=order && order<=bX+num) {
				ggg.get(i).iW.target(lensingSize);
				int num2 = order-(bX-num);
				if (bX-num>=0)
					setValue(ggg.get(i).iX, marginX +(bX-num)*size+num2*lensingSize);
				else
					setValue(ggg.get(i).iX, marginX +order*lensingSize);
			}	
			else{
				ggg.get(i).iW.target(size);
				if (order<bX-num)
					setValue(ggg.get(i).iX, marginX +order*size);
				else if (order>bX+num){
					if (bX-num>=0)
						setValue(ggg.get(i).iX, marginX +(order-(num*2+1))*size+(num*2+1)*lensingSize);
					else{
						int num3= bX+num+1;
						if (num3>0)
							setValue(ggg.get(i).iX, marginX +(order-num3)*size+num3*lensingSize);
					}	
				}	
			}	
		}
		for (int j=0;j<ggg.size();j++){
			int order = ggg.get(j).order;
			if (bY-num<=order && order<=bY+num){
				ggg.get(j).iH.target(lensingSize);
				int num2 = order-(bY-num);
				if (bY-num>=0)
					setValue(ggg.get(j).iY, marginY +(bY-num)*size+num2*lensingSize);
				else
					setValue(ggg.get(j).iY, marginY +order*lensingSize);
			}	
			else{
				ggg.get(j).iH.target(size);
				if (order<bY-num)
					setValue(ggg.get(j).iY, marginY +order*size);
				else if (order>bY+num){
					if (bY-num>=0)
						setValue(ggg.get(j).iY, marginY +(order-(num*2+1))*size+(num*2+1)*lensingSize);
					else{
						int num3= bY+num+1;
						if (num3>0)
							setValue(ggg.get(j).iY, marginY +(order-num3)*size+num3*lensingSize);
					}	
				}	
			}	
		}
		
		
		for (int i=0;i<ggg.size();i++){
			ggg.get(i).iH.update();
			ggg.get(i).iW.update();
			ggg.get(i).iX.update();
			ggg.get(i).iY.update();
		}
		
		// Draw gene names on X and Y axes
		for (int i=0;i<ggg.size();i++){
			float ww = ggg.get(i).iW.value;
			if (ww>10){
				float xx =  ggg.get(i).iX.value;
				// Draw rose chart
				/*
				if (Venn_Overview.numMiner>0){
					float[] aValues = new float[Venn_Overview.numMiner];
					for (int r=0;r<Venn_Overview.numMiner && main.Gene.hGenes!=null;r++){
						String g = gen.get(i);
						if (main.Gene.hGenes.get(g) == null) continue;// thread exception
						//int count = main.Gene.hGenes.get(g)[r];
						//float val = PApplet.map(count, 0, main.Gene.maxRelationOfGenes, 0, 1);
						//aValues[r] = val;
					}
					float x4 = xx+ww/2;
					float y4 = marginY-20;
				//	drawRose(x4, y4, ww*2f, aValues);
				}*/
				
				this.fill(150,150,150);
				this.textAlign(PApplet.LEFT);
				float al = -PApplet.PI/2;
				this.translate(xx+ww/2+5,marginY-8);
				this.rotate(al);
				this.text(ggg.get(i).name, 0,0);
				this.rotate(-al);
				this.translate(-(xx+ww/2+5), -(marginY-8));
			}
			float hh =ggg.get(i).iH.value;
			if (hh>10){
				float yy =  ggg.get(i).iY.value;
				this.fill(150,150,150);
				this.textAlign(PApplet.RIGHT);
				this.text(ggg.get(i).name, marginX-6, yy+hh/2+5);
			}
		}
			
		
		
		this.noStroke();
		for (int i=0;i<ggg.size();i++){
			// Check if this is grouping
			//if (ggg.get(i).orderReading !=ggg.get(i).orderParent) continue;
			
			float xx =  ggg.get(i).iX.value;
			float ww = ggg.get(i).iW.value;
			for (int j=0;j<ggg.size();j++){
				float yy =  ggg.get(j).iY.value;
				float hh =ggg.get(j).iH.value;
				// Draw Rosemary chart
				if (Venn_Overview.minerGlobalIDof !=null){
					if (geneRelationList==null || geneRelationList[i][j]==null) continue; // no relation of two genes
					
					float[] aValues = new float[Venn_Overview.minerGlobalIDof.length];
					for (int i2=0;i2<geneRelationList[i][j].size();i2++){
						int localRalationIndex = geneRelationList[i][j].get(i2);
						aValues[localRalationIndex] = 1;
					}
					drawRose(xx+ww/2, yy+hh/2, PApplet.min(ww,hh), aValues);
				}
			}
		}
		
		float x2 = this.width-600;
		
		this.fill(255);
		this.textAlign(PApplet.LEFT);
		this.text("File: "+currentFile, x2, 80);
		// find minerID index
		if (Venn_Overview.minerGlobalIDof!=null){
			if (currentRelation>=0){
				Color color = getMinerColor(Venn_Overview.globalToLocal(currentRelation));
				this.fill(color.getRGB());
				this.text("Realationship "+currentRelation+": "+minerList.get(currentRelation), x2+250, 100);
				this.text("Total genes: "+ggg.size(), x2+250, 120);
				this.text("Total relations: "+pairs[currentRelation].size(), x2+250, 140);
			}
			this.fill(255);
			this.text("Pathway summary", x2, 100);
			this.text("Total genes: "+allGenes.size(), x2, 120);
			int totalRelations = 0;
			for (int i=0;i<pairs.length;i++){
				totalRelations+=pairs[i].size();
			}
			this.text("Total relations: "+totalRelations, x2, 140);
		}
		vennOverview.draw(x2+50,120,10);
		vennDetail.draw(x2+100,500,10);
		
		// Draw button
		button.draw();
		popupOrder.draw(this.width-379);
		popupRelation.draw(this.width-500);
	}	
	
	
	public void setValue(Integrator inter, float value) {
		if (ggg.size()<500){
			inter.target(value);
		}
		else{
			inter.set(value);
		}
	}
		
	
	public void drawRose(float xx2, float yy2, float rr2, float[] relationship) {
		float lastAng = -PApplet.PI/2;
		this.noStroke();
		for (int i = 0; i < relationship.length; i++){
			Color color = getMinerColor(i);
			this.fill(color.getRGB());
			float alpha = PApplet.PI*2/relationship.length;
			this.arc(xx2,yy2, rr2*relationship[i], rr2*relationship[i], lastAng, lastAng+alpha);
			lastAng += alpha;  
		}
	}
	

		
	
	public void mouseClicked() {
		if (button.b>=0){
			String fileName =  loadFile(new Frame(), "Open your file", "..", ".txt");
			if (fileName.equals("..null"))
				return;
			else{
				currentFile = fileName;
				//VEN DIAGRAM
				vennOverview = new Venn_Overview(this);
				vennDetail = new Venn_Detail(this);
				thread1=new Thread(loader1);
				thread1.start();
				
			}
		}
		else if (popupRelation.b>=0){
			popupRelation.mouseClicked();
		}
		else if (popupOrder.b>=0){
			popupOrder.mouseClicked();
		}
		else if (vennOverview!=null){
			vennOverview.mouseClicked();
			if (vennOverview.brushing>=0)
				vennDetail.compute(currentRelation);
			update();
		}
	}
	
	public String loadFile (Frame f, String title, String defDir, String fileType) {
		  FileDialog fd = new FileDialog(f, title, FileDialog.LOAD);
		  fd.setFile(fileType);
		  fd.setDirectory(defDir);
		  fd.setLocation(50, 50);
		  fd.show();
		  String path = fd.getDirectory()+fd.getFile();
	      return path;
	}
	
	
	public void keyPressed() {
		if (this.key == '+') {
			currentRelation++;
			if (currentRelation>=minerList.size())
				currentRelation = 0;
			update();
		}
		else if (this.key == '-') {
			currentRelation--;
			if (currentRelation<0)
				currentRelation = minerList.size()-1;
			update();
		}
		if (this.key == 'q' || this.key == 'Q'){
			reveseGenesForDrawing();
		}
		if (this.key == 'w' || this.key == 'W'){
			swapGenesForDrawing();
		}
		if (this.key == 'l' || this.key == 'L'){
			isLensing = !isLensing;
		}
		if (this.key == 'n' || this.key == 'N')
			main.MainViewer.orderByName();
		if (this.key == 's' || this.key == 'S'){
			thread2=new Thread(loader2);
			thread2.start();
		}
		if (this.key == 'g' || this.key == 'G'){
			thread3=new Thread(loader3);
			thread3.start();
		}
	}
	
	public void update(){
		/*size = (800-marginY-200)/genes[currentMiner].size();

		iW = new ArrayList<Integrator>();
		iH = new ArrayList<Integrator>();
		for (int i=0;i<genes[currentMiner].size();i++){
			iW.add(new Integrator(0));
			iH.add(new Integrator(0));
		}*/
	}
		
	// Thread for Venn Diagram
	class ThreadLoader1 implements Runnable {
		public ThreadLoader1() {}
		@SuppressWarnings("unchecked")
		public void run() {
			 // Initialize best plots
			pairs = new ArrayList[minerList.size()];
			for (int i=0;i<minerList.size();i++){
				pairs[i] = new ArrayList<String>();
			}
			genes = new ArrayList[minerList.size()];
			for (int i=0;i<minerList.size();i++){
				genes[i] = new ArrayList<String>();
			}
			
			allGenes = new ArrayList<String>();
			ggg = new ArrayList<Gene>();
			geneRelationList = null;

			
			for (processingMiner=0;processingMiner<minerList.size();processingMiner++){
				 message = "Processing miner ("+processingMiner+"/"+minerList.size()
					+"): "+minerList.get(processingMiner);
				 computeRelationship(currentFile, processingMiner);
				
			}
			System.out.println();
		
			vennOverview.compute();
			
			// Computer the summary for each Gene
			Gene.compute();
			
			Gene.computeGeneRalationList();
			//write();
		
			/*
			 System.out.println("BRCA1 NBN= "+computeDis(0,1));
			 System.out.println("ADP ATM= "+computeDis(6,3));
			int index =  getSimilarGene(0, new ArrayList<Integer>());
			if (index>=0)
				System.out.println("Most similar to BRA1= "+ggg.get(index).name+"	dis="+computeDis(0,2));
			
			*/
		 }
	}
	
	
		
	
	//Update genes for drawing
	public void write(){	
		String outFile =  currentFile.replace(".owl", ".txt");
		int total =0;
		for (int m=0;m<Venn_Overview.minerGlobalIDof.length;m++){
			int globalMinerId = Venn_Overview.minerGlobalIDof[m];
			total += pairs[globalMinerId].size();
		}	
	
		String[] outStrings = new String[total];
		int count=0;
		for (int m=0;m<Venn_Overview.minerGlobalIDof.length;m++){
			int globalMinerId = Venn_Overview.minerGlobalIDof[m];
			for (int p=0;p<pairs[globalMinerId].size();p++){
				outStrings[count] = pairs[globalMinerId].get(p)+"\t"+minerList.get(globalMinerId).getName();
				count++;
			}
		}	
		this.saveStrings(outFile, outStrings);
	}
	//Reverse genes for drawing
	public void reveseGenesForDrawing(){	
		for (int i=0;i<ggg.size();i++){
			ggg.get(i).order = ggg.size()-ggg.get(i).order-1;
		}
	}
	//Swap genes for drawing
	public void swapGenesForDrawing(){	
		for (int i=0;i<ggg.size();i++){
			ggg.get(i).order =(ggg.get(i).order+ ggg.size()/2)% ggg.size();
		}
	}
	
	// Order genes by name
	public static void orderByName(){	
		Map<String, Integer> unsortMap = new HashMap<String, Integer>();
		for (int i=0;i<ggg.size();i++){
			unsortMap.put(ggg.get(i).name, ggg.get(i).orderReading);
		}
		Map<String, Integer> treeMap = new TreeMap<String, Integer>(unsortMap);
		int count=0;
		for (Map.Entry<String, Integer> entry : treeMap.entrySet()) {
			int inputOrder = entry.getValue();
			ggg.get(inputOrder).order = count;
			count++;
		}
	}
	
	// Order genes by a relation
	public static void orderByRelation(int orederedRelation){	
		Map<String, Integer> mapGene = new HashMap<String, Integer>();
		for (int i=0;i<ggg.size();i++){
			mapGene.put(ggg.get(i).name, i);
		}
		
		
		Map<String, Integer> unsortMap = new HashMap<String, Integer>();
		for (int i=0;i<ggg.size();i++){
			unsortMap.put(ggg.get(i).name, 0);
		}
		
		for (int i=0;i<pairs[orederedRelation].size();i++){
			String pair = pairs[orederedRelation].get(i);
			String gene1 = pair.split("\t")[0];
			int c = unsortMap.get(gene1);
			c++;
			unsortMap.put(gene1, c);
		}
		
		Map<String, Integer> sortedMap = sortByComparator(unsortMap);
		
		int count=0;
		for (Map.Entry<String, Integer> entry : sortedMap.entrySet()) {
			String gene1 = entry.getKey();
			int inputOrder = mapGene.get(gene1);
			ggg.get(inputOrder).order = count;
			count++;
		}
	}
	
	
	private static Map<String, Integer> sortByComparator(Map<String, Integer> unsortMap) {
		// Convert Map to List
		List<Map.Entry<String, Integer>> list = 
			new LinkedList<Map.Entry<String, Integer>>(unsortMap.entrySet());
 
		// Sort list with comparator, to compare the Map values
		Collections.sort(list, new Comparator<Map.Entry<String, Integer>>() {
			public int compare(Map.Entry<String, Integer> o1,
                                           Map.Entry<String, Integer> o2) {
				return (o1.getValue()).compareTo(o2.getValue());
			}
		});
 
		// Convert sorted map back to a Map
		Map<String, Integer> sortedMap = new LinkedHashMap<String, Integer>();
		for (Iterator<Map.Entry<String, Integer>> it = list.iterator(); it.hasNext();) {
			Map.Entry<String, Integer> entry = it.next();
			sortedMap.put(entry.getKey(), entry.getValue());
		}
		return sortedMap;
	}
	
	
	// Thread for ordering
	class ThreadLoader2 implements Runnable {
		public ThreadLoader2() {}
		public void run() {
			orderBySimilarity();
		}
	}	
	// Thread for grouping
	class ThreadLoader3 implements Runnable {
		public ThreadLoader3() {}
		public void run() {
			groupBySimilarity();
		}
	}	
	
	// Group by similarity
	public void groupBySimilarity(){	
		int indexLeader =0;
		for (int i=1;i<ggg.size();i++){
		//	if (computeDis(ggg.get(indexLeader).name, ggg.get(i).name)==0){
		//		ggg.get(i).order = ggg.get(indexLeader).order;
		//	}
		//	else{
		//		indexLeader=i;
		//	}
		}
	}
	
	// Order by similarity
	public void orderBySimilarity(){	
		Map<String, Integer> mapGene = new HashMap<String, Integer>();
		for (int i=0;i<ggg.size();i++){
			mapGene.put(ggg.get(i).name, i);
		}
		
		Map<String, Integer> unsortMap = new HashMap<String, Integer>();
		for (int i=0;i<ggg.size();i++){
			unsortMap.put(ggg.get(i).name, 0);
		}
		
		for (int m=0;m<pairs.length;m++){
			for (int i=0;i<pairs[m].size();i++){
				String pair = pairs[m].get(i);
				String gene1 = pair.split("\t")[0];
				String gene2 = pair.split("\t")[1];
				int c = unsortMap.get(gene1);
				c++;
				unsortMap.put(gene1, c);
				c = unsortMap.get(gene2);
				c++;
				unsortMap.put(gene2, c);
			}
		}	
		
		Map<String, Integer> sortedMap = sortByComparator(unsortMap);
		
		
		Map.Entry<String, Integer> firstEntry = null;
		for (Map.Entry<String, Integer> entry : sortedMap.entrySet()) {
			firstEntry = entry;
			break;
		}
		int index1 = mapGene.get(firstEntry.getKey());
		int orderReading1 = ggg.get(index1).orderReading;
		
		ArrayList<Integer> processedGenes =  new ArrayList<Integer>();
		for (int i=0;i<ggg.size();i++){
			ggg.get(index1).order=i;
			processedGenes.add(orderReading1);
			if (i==ggg.size()-1) break;
			int similarIndex =  getSimilarGene(orderReading1,processedGenes);
			index1 = similarIndex;
			orderReading1 = ggg.get(index1).orderReading;
		}
	}
	
	public int getSimilarGene(int orderReading1, ArrayList<Integer> a){
		int minDis = Integer.MAX_VALUE;
		int minIndex = -1;
		for (int i=0;i<ggg.size();i++){
			int orderReading2 = ggg.get(i).orderReading;
			if (orderReading1==orderReading2) continue;
			if (a.contains(orderReading2)) continue;
			int dis = computeDis(orderReading1,orderReading2);
			if (dis<minDis){
				minDis = dis;
				minIndex = i;
			}
		}
		return minIndex;
	}
	public int computeDis(int orderReading1, int orderReading2){
		int dis = 0;
		
		for (int i=0;i<ggg.size();i++){
			int orderReading3 = ggg.get(i).orderReading;
			if (orderReading3==orderReading1 || orderReading3 ==orderReading2){
				dis += computeDisOfArrayList(geneRelationList[orderReading1][orderReading2],geneRelationList[orderReading2][orderReading1]);
			}
			else{
				dis += computeDisOfArrayList(geneRelationList[orderReading1][orderReading3],geneRelationList[orderReading2][orderReading3]);
				dis += computeDisOfArrayList(geneRelationList[orderReading3][orderReading1],geneRelationList[orderReading3][orderReading2]);
			}
		}
		return dis;
	}
	public int computeDisOfArrayList(ArrayList<Integer> a1, ArrayList<Integer> a2){
		if (a1==null && a2==null) return 0;
		else if (a1==null) return a2.size();
		else if (a2==null) return a1.size();
		
		int numCommonElements = 0;
		for (int i=0;i<a1.size();i++){
			int num1 = a1.get(i);
			if (a2.contains(num1))
				numCommonElements++;
		}
		return (a1.size()+a2.size()-5*numCommonElements);
	}
}
