package org.biopax.paxtools.pattern.util;

/**
 * Distinguishes between input and output.
 *
 * @author Ozgun Babur
 */
public enum RelType
{
	INPUT,
	OUTPUT
}
